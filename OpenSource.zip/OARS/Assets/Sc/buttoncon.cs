﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class buttoncon : MonoBehaviour
{
    public void Onclickbtn()
    {
        Debug.Log("Clickbtn");

    }
}
